% generate_all_cutoff_sweeps.m
%
% Master driver that REPLICATES THE ACTUAL RUN behind EUSIPCO 2026 Fig. 2.
% It regenerates the cut-off sweep .mat files for all three ASR variants and
% then renders the combined 2 x 3 cohort figure.
%
% This is the de-duplicated replacement for the three original live scripts
% (baselineASR_DataModified, adaptiveASR_DataModified, HMOASR_DataModified):
% each is now one call to compute_asr_cutoff_sweep with a different method.
%
% PREREQUISITES (must be on the MATLAB path, not shipped here):
%   - helperASR_cleaning_preporcessEEG
%   - asr_calibrate / asr_process                       (baseline, EEGLAB clean_rawdata)
%   - asr_calibrate_Version1 / asr_process_version1     (adaptive EMA-ASR)
%   - hmo_asr_calibrate / hmo_asr_process               (HMO-ASR)
%   - subject_<j>.mat recordings under opts.subjectDir
% Toolboxes: Statistics and Machine Learning, Signal Processing.
%
% Outputs are written into ../data so plotEUSIPCOFigure2.m picks them up.

clear; clc; close all;
thisDir   = fileparts(mfilename('fullpath'));        % .../eusipco_fig2/generate
pkgDir    = fileparts(thisDir);                       % .../eusipco_fig2
addpath(thisDir, pkgDir);

opts = struct();
opts.subjectIDs = 1:10;                               % subjects to sweep
opts.subjectDir = 'H:\Adaptive_EMA_ASR\dataset';      % <-- set to your dataset path
opts.fs         = 500;                                % sampling rate (Hz)
opts.calibSec   = [2 42];                             % calibration window (s)
opts.useGPU     = true;                               % pass-through to asr_process
opts.saveDir    = fullfile(pkgDir, 'data');           % feed plotEUSIPCOFigure2

% --- Run the three sweeps (cut-off grid + step size are set per method) ---
compute_asr_cutoff_sweep('baseline', opts);
compute_asr_cutoff_sweep('adaptive', opts);
compute_asr_cutoff_sweep('hmo',      opts);

% --- Render the combined cohort figure (auto-fills the HMO column) --------
S = plotEUSIPCOFigure2(struct( ...
    'dataPath', opts.saveDir, ...
    'saveDir',  fullfile(pkgDir, 'figs'), ...
    'hmoFile',  'ASR_HMO_cutOff_exp.mat'));

fprintf('\nFigure 2 regenerated:\n  %s\n  %s\n', S.savedPaths{:});
