function h = plot_asr_shaded(percentModified, varianceReduced, k_list, titleStr)
%PLOT_ASR_SHADED  Single-method shaded cut-off plot (mean +/- 1 SD over subjects).
%
%   h = PLOT_ASR_SHADED(PERCENTMODIFIED, VARIANCEREDUCED, K_LIST, TITLESTR)
%   draws one method's cut-off sweep: the percentage of data modified (blue,
%   left axis) and the variance reduction (red, right axis) versus the ASR
%   cut-off k on a log x-axis, each as a cohort mean with a +/- 1 SD band.
%
%   PERCENTMODIFIED, VARIANCEREDUCED : nSubject x nCutoff matrices
%       (stack the per-subject curves, e.g. vertcat(dataModified_data{:})).
%   K_LIST   : 1 x nCutoff cut-off grid. If omitted, a 1..1000 log grid is assumed.
%   TITLESTR : panel title (e.g. 'Original-ASR:Entire Data').
%
%   This is the helper referenced by the original *_DataModified scripts. The
%   combined 2 x 3 paper figure is produced separately by plotEUSIPCOFigure2.m;
%   use this function for a quick per-method view.

    if nargin < 4 || isempty(titleStr), titleStr = 'ASR cut-off sweep'; end
    if nargin < 3 || isempty(k_list)
        k_list = logspace(0, 3, size(percentModified, 2));
    end
    k_list = k_list(:)';

    cBlue = [0.10 0.35 0.75];
    cRed  = [0.80 0.18 0.18];

    mMod = mean(percentModified, 1);   sMod = std(percentModified, 0, 1);
    mVar = mean(varianceReduced, 1);   sVar = std(varianceReduced, 0, 1);

    ax = gca; set(ax, 'XScale', 'log'); hold(ax, 'on');

    % Left axis: % data modified
    yyaxis left
    shade(k_list, mMod, sMod, cBlue);
    plot(k_list, mMod, '-o', 'Color', cBlue, 'MarkerFaceColor', cBlue, 'LineWidth', 1.6, 'MarkerSize', 4);
    set(ax, 'YColor', cBlue); ylabel('% Data Modified'); ylim([0 100]);

    % Right axis: % variance reduced
    yyaxis right
    shade(k_list, mVar, sVar, cRed);
    plot(k_list, mVar, '-s', 'Color', cRed, 'MarkerFaceColor', cRed, 'LineWidth', 1.6, 'MarkerSize', 4);
    set(ax, 'YColor', cRed); ylabel('% Variance Reduced'); ylim([0 100]);

    xlabel('ASR Cutoff Parameter (k)');
    xlim([min(k_list) max(k_list)]);
    title(titleStr); grid on; box on;
    legend({'', 'Data Modified', '', 'Variance Reduced'}, 'Location', 'northeast');
    h = ax;
end

% =====================================================================
function shade(x, m, s, col)
% Mean +/- 1 SD ribbon clipped to [0, 100].
    x = x(:)'; m = m(:)'; s = s(:)';
    lo = max(m - s, 0); hi = min(m + s, 100);
    fill([x fliplr(x)], [lo fliplr(hi)], col, ...
        'FaceAlpha', 0.16, 'EdgeColor', 'none', 'HandleVisibility', 'off');
end
