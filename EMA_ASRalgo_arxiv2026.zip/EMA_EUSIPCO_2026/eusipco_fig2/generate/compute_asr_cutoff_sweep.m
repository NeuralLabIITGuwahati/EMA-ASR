function S = compute_asr_cutoff_sweep(method, opts)
%COMPUTE_ASR_CUTOFF_SWEEP  Replicate the EUSIPCO 2026 Fig. 2 cut-off sweep run.
%
%   S = COMPUTE_ASR_CUTOFF_SWEEP(METHOD, OPTS) reproduces, for one artifact-
%   removal method, the per-subject cut-off sweep that generates the data behind
%   EUSIPCO 2026 Fig. 2 (cut-off sensitivity). For every subject and every ASR
%   cut-off k it cleans two segments — (1) the post-calibration "entire data"
%   and (2) the calibration segment — and records two summary measures:
%
%       data_modified    = 100 * RMS(cleaned - raw) / RMS(raw)        (relative RMS distortion, %)
%       variance_reduced = 100 * (var(raw) - var(cleaned)) / var(raw) (%)
%
%   Results are stored as 1 x nSubject cell arrays (one 1 x nCutoff curve per
%   subject) and saved to a .mat file containing exactly the variables the
%   plotting code (plotEUSIPCOFigure2.m) expects:
%
%       cutoff_values
%       dataModified_data    varianceReduced_data     (entire-recording scope)
%       dataModified_calib   varianceReduced_calib    (calibration scope)
%
%   METHOD selects the ASR variant:
%       'baseline' : static ASR        -> asr_calibrate          / asr_process
%       'adaptive' : EMA adaptive ASR  -> asr_calibrate_Version1  / asr_process_version1
%       'hmo'      : HMO ASR           -> hmo_asr_calibrate       / hmo_asr_process
%
%   This is a faithful, de-duplicated arrangement of the three original
%   *_DataModified live scripts (baselineASR / adaptiveASR / HMOASR). The
%   numerical recipe is preserved EXACTLY so a re-run reproduces the shipped
%   .mat files — including the deliberate double removal of the look-ahead pad
%   before the distortion metric (see the NOTE inside the cut-off loop).
%
%   REQUIRED on the MATLAB path (NOT shipped with this package):
%       helperASR_cleaning_preporcessEEG   (band-pass / notch / zero-mean preproc)
%       the calibrate/process pair for the chosen method
%           baseline -> asr_calibrate, asr_process            (EEGLAB clean_rawdata)
%           adaptive -> asr_calibrate_Version1, asr_process_version1
%           hmo      -> hmo_asr_calibrate, hmo_asr_process
%   Subject recordings subject_<j>.mat (each with EEG.data, C x T) under
%   opts.subjectDir, sampled at opts.fs.
%
%   OPTS fields (all optional; defaults in the table below):
%       subjectIDs   subjects to sweep                       default 1:10
%       subjectDir   folder holding subject_<j>.mat          default 'H:\Adaptive_EMA_ASR\dataset'
%       fs           sampling rate (Hz)                      default 500
%       calibSec     [start end] of calibration segment (s)  default [2 42]
%       lookaheadSec ASR look-ahead / pad length (s)         default 0.25
%       windowLenSec ASR processing window (s)               default 0.5
%       useGPU       pass-through to asr_process             default true
%       cutoffs      override the per-method cut-off grid    default per method
%       stepSize     override the per-method step size       default per method
%       saveDir      output folder for the .mat              default this file's folder
%       saveFile     output .mat name                        default per method
%       doPlot       draw per-method shaded figure at end    default false
%
%   See also PLOTEUSIPCOFIGURE2, PLOT_ASR_SHADED, GENERATE_ALL_CUTOFF_SWEEPS.

    if nargin < 1 || isempty(method), method = 'baseline'; end
    if nargin < 2, opts = struct(); end
    thisDir = fileparts(mfilename('fullpath'));

    % --- Per-method configuration ----------------------------------------
    % Only these four things differ between the three original scripts:
    %   the calibrate/process function handles, the step size, whether the
    %   cut-off is passed to the process call, and the cut-off grid + save name.
    cfg = methodConfig(method);

    % --- Merge user options over the defaults ----------------------------
    defaults = struct( ...
        'subjectIDs',   1:10, ...
        'subjectDir',   'H:\Adaptive_EMA_ASR\dataset', ...
        'fs',           500, ...
        'calibSec',     [2 42], ...
        'lookaheadSec', 0.25, ...
        'windowLenSec', 0.5, ...
        'useGPU',       true, ...
        'cutoffs',      cfg.cutoffs, ...
        'stepSize',     cfg.stepSize, ...
        'saveDir',      thisDir, ...
        'saveFile',     cfg.saveFile, ...
        'doPlot',       false);
    for f = fieldnames(defaults)'
        if ~isfield(opts, f{1}) || isempty(opts.(f{1})), opts.(f{1}) = defaults.(f{1}); end
    end
    if ~isfolder(opts.saveDir), mkdir(opts.saveDir); end

    fs           = opts.fs;
    cutoff_values = opts.cutoffs(:)';
    nK           = numel(cutoff_values);
    subs         = opts.subjectIDs(:)';
    nSub         = max(subs);                 % cell index is the subject ID
    lookahead    = opts.lookaheadSec;
    padLength    = round(lookahead * fs);
    windowLength = opts.windowLenSec;

    % Cohort containers indexed by subject ID (matches the original scripts)
    [dataModified_data,  varianceReduced_data]  = deal(cell(1, nSub));
    [dataModified_calib, varianceReduced_calib] = deal(cell(1, nSub));

    % =====================================================================
    for j = subs
        % --- Load one subject's recording --------------------------------
        d = load(fullfile(opts.subjectDir, sprintf('subject_%d.mat', j)));
        originalSignal = double(d.EEG.data);

        % --- Preprocess (band-pass / notch / zero-mean) ------------------
        filteredSignal = helperASR_cleaning_preporcessEEG(originalSignal, fs);

        % --- Segment into calibration and post-calibration "entire" data -
        calibStart = round(opts.calibSec(1) * fs);
        calibEnd   = round(opts.calibSec(2) * fs);
        calibrationSignal = filteredSignal(:, calibStart:calibEnd);
        artifactSignal    = filteredSignal(:, calibEnd + 1:end);   % "entire data" scope

        % --- Front-pad both segments by the look-ahead length ------------
        z = @(X) [zeros(size(X, 1), padLength), X];
        paddedEntire = z(artifactSignal);
        paddedCalib  = z(calibrationSignal);

        % --- Per-cut-off accumulators ------------------------------------
        [dm_entire, vr_entire] = deal(zeros(1, nK));
        [dm_calib,  vr_calib]  = deal(zeros(1, nK));

        for i = 1:nK
            cutoff = cutoff_values(i);

            % Calibrate on the clean calibration segment at this cut-off
            state = cfg.calibrate(calibrationSignal, fs, cutoff);

            % Process both segments. The adaptive variant additionally takes
            % the cut-off as a trailing argument; the others do not.
            if cfg.passCutoff
                cleanedEntire = cfg.process(paddedEntire, fs, state, ...
                    windowLength, lookahead, opts.stepSize, [], [], opts.useGPU, cutoff);
                cleanedCalib  = cfg.process(paddedCalib,  fs, state, ...
                    windowLength, lookahead, opts.stepSize, [], [], opts.useGPU, cutoff);
            else
                cleanedEntire = cfg.process(paddedEntire, fs, state, ...
                    windowLength, lookahead, opts.stepSize, [], [], opts.useGPU);
                cleanedCalib  = cfg.process(paddedCalib,  fs, state, ...
                    windowLength, lookahead, opts.stepSize, [], [], opts.useGPU);
            end

            % Remove the look-ahead padding (crop #1)
            cleanedEntire = cleanedEntire(:, padLength + 1:end);
            cleanedCalib  = cleanedCalib(:,  padLength + 1:end);

            % --- Variance reduction (uses the once-cropped cleaned signal) -
            vr_entire(i) = varianceReducedPct(artifactSignal,    cleanedEntire);
            vr_calib(i)  = varianceReducedPct(calibrationSignal, cleanedCalib);

            % --- Relative RMS distortion ("% data modified") -------------
            % NOTE: the original scripts strip padLength a SECOND time here,
            % only for the distortion metric. It is preserved verbatim so the
            % regenerated .mat matches the shipped files. To use the full
            % cleaned signal instead, drop the (:, padLength+1:end) below.
            dm_entire(i) = relRmsDistortionPct(cleanedEntire(:, padLength + 1:end), artifactSignal);
            dm_calib(i)  = relRmsDistortionPct(cleanedCalib(:,  padLength + 1:end), calibrationSignal);
        end

        % Store this subject's curves (cell index == subject ID)
        dataModified_data{j}     = dm_entire;
        varianceReduced_data{j}  = vr_entire;
        dataModified_calib{j}    = dm_calib;
        varianceReduced_calib{j} = vr_calib;

        fprintf('  %s: subject %d done (%d cut-offs)\n', cfg.name, j, nK);
    end

    % --- Save in the layout plotEUSIPCOFigure2.m expects -----------------
    outPath = fullfile(opts.saveDir, opts.saveFile);
    save(outPath, 'cutoff_values', ...
        'dataModified_data',  'varianceReduced_data', ...
        'dataModified_calib', 'varianceReduced_calib');
    fprintf('%s sweep saved -> %s\n', cfg.name, outPath);

    S = struct('method', method, 'name', cfg.name, 'cutoffs', cutoff_values, ...
        'dataModified_data',  {dataModified_data},  'varianceReduced_data',  {varianceReduced_data}, ...
        'dataModified_calib', {dataModified_calib}, 'varianceReduced_calib', {varianceReduced_calib}, ...
        'savedPath', outPath);

    % --- Optional per-method shaded figure (paper-style, one method) ------
    if opts.doPlot
        PM_d = vertcat(dataModified_data{:});      VR_d = vertcat(varianceReduced_data{:});
        PM_c = vertcat(dataModified_calib{:});     VR_c = vertcat(varianceReduced_calib{:});
        figure; plot_asr_shaded(PM_d, VR_d, cutoff_values, sprintf('%s:Entire Data', cfg.name));
        figure; plot_asr_shaded(PM_c, VR_c, cutoff_values, sprintf('%s:Calibration Data', cfg.name));
    end
end

% =====================================================================
function cfg = methodConfig(method)
% The only per-method differences distilled from the three original scripts.
    switch lower(method)
        case 'baseline'   % static / Original ASR
            cfg = struct('name', 'Original-ASR', ...
                'calibrate', @asr_calibrate, 'process', @asr_process, ...
                'passCutoff', false, 'stepSize', 32, ...
                'cutoffs', [1 2 5 10 15 20 30 40 50 70 90 100 200 500 700 1000], ...
                'saveFile', 'ASR_baseline_cutOff_exp.mat');
        case 'adaptive'   % EMA adaptive ASR
            cfg = struct('name', 'Adaptive-ASR', ...
                'calibrate', @asr_calibrate_Version1, 'process', @asr_process_version1, ...
                'passCutoff', true, 'stepSize', 32, ...
                'cutoffs', [1 2 5 10 15 20 30 40 50 70 90 100 200 500 700 1000], ...
                'saveFile', 'ASR_Adaptive_cutOff_exp_replica.mat');
        case 'hmo'        % HMO ASR (sweep stops at 100, fractional step size)
            cfg = struct('name', 'HMO-ASR', ...
                'calibrate', @hmo_asr_calibrate, 'process', @hmo_asr_process, ...
                'passCutoff', false, 'stepSize', 0.25, ...
                'cutoffs', [1 2 5 10 15 20 30 40 50 70 90 100], ...
                'saveFile', 'ASR_HMO_cutOff_exp.mat');
        otherwise
            error('compute_asr_cutoff_sweep:method', ...
                'Unknown method "%s" (use baseline | adaptive | hmo).', method);
    end
end

% =====================================================================
function p = varianceReducedPct(raw, cleaned)
% Percentage reduction in signal variance after cleaning.
    vr = var(raw(:));
    p  = 100 * (vr - var(cleaned(:))) / vr;
end

% =====================================================================
function p = relRmsDistortionPct(cleaned, raw)
% 100 * RMS(cleaned - raw) / RMS(raw), after cropping both to a common length.
    n       = min(size(cleaned, 2), size(raw, 2));
    cleaned = cleaned(:, 1:n);
    raw     = raw(:, 1:n);
    diff    = cleaned - raw;
    p       = 100 * rms(diff(:)) / rms(raw(:));
end
