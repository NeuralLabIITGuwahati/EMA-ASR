% run_eusipco_fig2.m
%
% Reproduce EUSIPCO 2026 Fig. 2 (cutoff-sensitivity panel) for the 10-subject
% cohort (mean +/- 1 SD). Sweep results are read from the local ./data folder;
% output is written to ./figs.

clear; close all;
thisDir = fileparts(mfilename('fullpath'));
addpath(thisDir);

opts.dataPath = fullfile(thisDir, 'data');
opts.saveDir  = fullfile(thisDir, 'figs');
S = plotEUSIPCOFigure2(opts);

fprintf('Saved:\n  %s\n  %s\n', S.savedPaths{:});
