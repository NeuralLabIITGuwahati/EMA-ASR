function S = plotEUSIPCOFigure2(opts)
%PLOTEUSIPCOFIGURE2  Reproduce EUSIPCO 2026 Fig. 2 (cutoff-sensitivity panel).
%
%   A 2 x 3 panel grid is produced:
%     - columns are the three artifact-removal methods
%         HMO-ASR  |  Original-ASR (static)  |  Adaptive-ASR (EMA)
%     - rows are the temporal scope
%         top    : calibration segment
%         bottom : entire recording
%
%   In every panel the proportion of modified samples (blue, left axis) and
%   the variance reduction (red, right axis) are plotted as functions of the
%   ASR cutoff parameter k on a log x-axis. Each curve is the cohort mean over
%   subjects; the shaded band is +/- 1 SD across subjects. The standard
%   operating point k = 20 is marked with a dotted vertical line.
%
%   The HMO-ASR column is a placeholder: no HMO cutoff sweep ships with this
%   package, so the column is annotated "HMO sweep data pending". Drop in an
%   'hmoFile' that follows the same .mat layout to populate it (see below).
%
%   Defaults follow the paper: static sweep from ASR_baseline_cutOff_exp.mat,
%   adaptive (EMA) sweep from ASR_Adaptive_cutOff_exp_replica.mat, cohort of
%   N = 10 subjects, cutoff grid [1 ... 1000], operating point k = 20.

    if nargin < 1, opts = struct(); end
    thisDir = fileparts(mfilename('fullpath'));
    defaults = struct( ...
        'dataPath',     fullfile(thisDir, 'data'), ...
        'saveDir',      fullfile(thisDir, 'figs'), ...
        'baselineFile', 'ASR_baseline_cutOff_exp.mat', ...
        'adaptiveFile', 'ASR_Adaptive_cutOff_exp_replica.mat', ...
        'hmoFile',      '', ...
        'operatingK',   20, ...
        'yLimMod',      [0 100], ...
        'yLimVar',      [0 100]);
    for f = fieldnames(defaults)'
        if ~isfield(opts, f{1}), opts.(f{1}) = defaults.(f{1}); end
    end
    if ~isfolder(opts.saveDir), mkdir(opts.saveDir); end

    % --- Load cohort sweeps and reduce to mean / SD across subjects --------
    static = loadSweep(fullfile(opts.dataPath, opts.baselineFile));
    ema    = loadSweep(fullfile(opts.dataPath, opts.adaptiveFile));
    % HMO is optional: use opts.hmoFile if given, otherwise auto-detect a
    % sweep in the data folder. When none is found, the HMO column is a
    % placeholder. The HMO grid may be shorter (e.g. k up to 100) than the
    % others; per-method cut-off grids are honoured at plot time.
    hmoPath = resolveHMO(opts.dataPath, opts.hmoFile);
    if ~isempty(hmoPath)
        hmo = loadSweep(hmoPath);
    else
        hmo = [];   % placeholder column
    end
    cutoffs = static.cutoffs;   % representative grid for the output struct

    % --- Render and save ---------------------------------------------------
    fig  = drawFigure(hmo, static, ema, opts);
    base = fullfile(opts.saveDir, 'eusipco_fig2_cohort');
    print(fig, [base '.png'], '-dpng', '-r300');
    print(fig, [base '.pdf'], '-dpdf', '-bestfit');

    S = struct( ...
        'cutoffs',    cutoffs, ...
        'hmo',        hmo, ...
        'static',     static, ...
        'ema',        ema, ...
        'operatingK', opts.operatingK, ...
        'figHandle',  fig, ...
        'savedPaths', {{[base '.png'], [base '.pdf']}});
end

% =====================================================================
function p = resolveHMO(dataPath, hmoFile)
% Locate an HMO sweep: honour an explicit file name, else auto-detect common
% names in the data folder. Returns '' (placeholder) when nothing is found.
    p = '';
    if ~isempty(hmoFile)
        cand = fullfile(dataPath, hmoFile);
        if isfile(cand), p = cand; end
        return;
    end
    patterns = {'ASR_HMO_cutOff_exp.mat', 'ASR_HMO_cutOff_exp_*.mat', '*HMO*cutOff*.mat'};
    for i = 1:numel(patterns)
        f = dir(fullfile(dataPath, patterns{i}));
        if ~isempty(f), p = fullfile(f(1).folder, f(1).name); return; end
    end
end

% =====================================================================
function s = loadSweep(matFile)
% Load one cutoff-sweep .mat file and reduce each measure to a struct with
% .mean and .sd (1 x nCutoff) plus the subject count .n.
%
% Expected variables in the file:
%   cutoff_values            1 x K  (or K x 1) cutoff grid
%   dataModified_calib       1 x N cell, each cell a 1 x K vector
%   dataModified_data        1 x N cell
%   varianceReduced_calib    1 x N cell
%   varianceReduced_data     1 x N cell
    d = load(matFile);
    s.cutoffs                = double(d.cutoff_values(:))';
    s.dataModified_calib     = stackStats(d.dataModified_calib);
    s.dataModified_data      = stackStats(d.dataModified_data);
    s.varianceReduced_calib  = stackStats(d.varianceReduced_calib);
    s.varianceReduced_data   = stackStats(d.varianceReduced_data);
end

% =====================================================================
function st = stackStats(cellArr)
% Stack a 1 x N cell of 1 x K subject vectors into an N x K matrix, then take
% the per-cutoff mean and SD across subjects (NaNs ignored).
    rows = cellfun(@(v) double(v(:))', cellArr(:), 'UniformOutput', false);
    M    = cell2mat(rows);                 % N x K
    st.mean = mean(M, 1);                  % no NaNs in the shipped sweeps
    st.sd   = std(M, 0, 1);                % flag 0 -> normalise by N-1
    st.n    = size(M, 1);
end

% =====================================================================
function f = drawFigure(hmo, static, ema, opts)
    f = figure('Color', 'w', 'Position', [60 60 1400 760]);
    cBlue = [0.10 0.35 0.75];
    cRed  = [0.80 0.18 0.18];
    cGrey = [0.35 0.35 0.35];

    colData = {hmo,        static,                  ema};
    colName = {'HMO-ASR', 'Original-ASR (static)', 'Adaptive-ASR (EMA)'};
    rowSeg  = {'calib',           'data'};
    rowName = {'Calibration Data', 'Entire Data'};

    % Common x-limits so the three columns line up, even when methods use
    % different cut-off grids (HMO may stop at a lower k than the others).
    allK = [];
    for src = colData
        if ~isempty(src{1}), allK = [allK src{1}.cutoffs(:)']; end %#ok<AGROW>
    end
    if isempty(allK), allK = [1 1000]; end
    xLims = [min(allK) max(allK)];

    for r = 1:2
        for c = 1:3
            ax  = subplot(2, 3, (r - 1) * 3 + c);
            src = colData{c};

            if isempty(src)
                % ---- Placeholder column (no sweep available) ------------
                set(ax, 'XScale', 'log'); xlim(xLims); ylim(opts.yLimMod);
                grid on; box on;
                ylabel('Data modified (%)', 'Color', cBlue);
                set(ax, 'YColor', cBlue);
                text(0.5, 0.55, sprintf('HMO sweep\ndata pending'), ...
                    'Units', 'normalized', 'HorizontalAlignment', 'center', ...
                    'Color', [0.45 0.45 0.45], 'FontAngle', 'italic', ...
                    'FontSize', 11);
                if r == 1, addLegend(ax, cBlue, cRed, cGrey, opts.operatingK); end
            else
                kx = src.cutoffs;   % this method's own cut-off grid
                dm = src.(['dataModified_'    rowSeg{r}]);
                vr = src.(['varianceReduced_' rowSeg{r}]);

                % Left axis: proportion of modified samples
                yyaxis left; hold on;
                shadeBand(kx, dm.mean, dm.sd, cBlue, opts.yLimMod);
                plot(kx, dm.mean, '-o', 'Color', cBlue, ...
                    'MarkerFaceColor', cBlue, 'LineWidth', 1.6, 'MarkerSize', 3.5);
                set(ax, 'YColor', cBlue); ylim(opts.yLimMod);
                ylabel('Data modified (%)', 'Color', cBlue);

                % Right axis: variance reduction
                yyaxis right; hold on;
                shadeBand(kx, vr.mean, vr.sd, cRed, opts.yLimVar);
                plot(kx, vr.mean, '-s', 'Color', cRed, ...
                    'MarkerFaceColor', cRed, 'LineWidth', 1.6, 'MarkerSize', 3.5);
                set(ax, 'YColor', cRed); ylim(opts.yLimVar);
                ylabel('Variance reduced (%)', 'Color', cRed);

                set(ax, 'XScale', 'log'); xlim(xLims); grid on; box on;
                xline(opts.operatingK, ':', 'Color', cGrey, 'LineWidth', 1.2);
            end

            % ---- Shared annotations -------------------------------------
            if r == 2, xlabel('ASR cutoff parameter k'); end
            title(sprintf('%s: %s', colName{c}, rowName{r}), ...
                'FontSize', 9.5, 'FontWeight', 'bold');
            set(ax, 'FontSize', 8);
        end
    end

    n = max([getfielddef(static), getfielddef(ema)]);
    annotation('textbox', [0.05 0.96 0.9 0.035], 'String', sprintf( ...
        ['EUSIPCO 2026 Fig. 2  -  cutoff sensitivity: data modified & ' ...
         'variance reduced vs k   (N = %d, mean +/- 1 SD)'], n), ...
        'EdgeColor', 'none', 'FontSize', 11, 'FontWeight', 'bold', ...
        'HorizontalAlignment', 'center');
end

% =====================================================================
function shadeBand(x, m, s, col, yl)
% Mean +/- 1 SD ribbon, clipped to the axis limits yl = [lo hi].
    x  = x(:)';  m = m(:)';  s = s(:)';
    lo = max(m - s, yl(1));
    hi = min(m + s, yl(2));
    fill([x fliplr(x)], [lo fliplr(hi)], col, ...
        'FaceAlpha', 0.16, 'EdgeColor', 'none', 'HandleVisibility', 'off');
end

% =====================================================================
function addLegend(ax, cBlue, cRed, cGrey, kOp)
% Build a manual legend in the (otherwise empty) placeholder panel.
    hold(ax, 'on');
    h1 = plot(ax, nan, nan, '-o', 'Color', cBlue, 'MarkerFaceColor', cBlue, 'LineWidth', 1.6);
    h2 = plot(ax, nan, nan, '-s', 'Color', cRed,  'MarkerFaceColor', cRed,  'LineWidth', 1.6);
    h3 = patch(ax, nan, nan, cBlue, 'FaceAlpha', 0.16, 'EdgeColor', 'none');
    h4 = patch(ax, nan, nan, cRed,  'FaceAlpha', 0.16, 'EdgeColor', 'none');
    h5 = plot(ax, nan, nan, ':', 'Color', cGrey, 'LineWidth', 1.2);
    legend([h1 h2 h3 h4 h5], { ...
        'Data modified (mean)', 'Variance reduced (mean)', ...
        'Data modified (\pm1 SD)', 'Variance reduced (\pm1 SD)', ...
        sprintf('Operating point k = %d', kOp)}, ...
        'Location', 'south', 'FontSize', 7, 'Box', 'off');
end

% =====================================================================
function n = getfielddef(s)
% Subject count from a loaded sweep (uses the data-modified/full-recording n).
    if isempty(s), n = 0; else, n = s.dataModified_data.n; end
end
