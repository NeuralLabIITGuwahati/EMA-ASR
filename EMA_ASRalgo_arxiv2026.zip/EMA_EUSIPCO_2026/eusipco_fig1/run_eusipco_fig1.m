% run_eusipco_fig1.m
%
% Reproduce EUSIPCO 2026 Fig. 1 for subject 10 (paper recipe).
% Data is read from the local ./data folder; output is written to ./figs.

clear; close all;
thisDir = fileparts(mfilename('fullpath'));
addpath(thisDir);

opts.dataPath = fullfile(thisDir, 'data');
opts.saveDir  = fullfile(thisDir, 'figs');
S = plotSingleSubjectEUSIPCOFigure1(10, opts);

fprintf('Saved:\n  %s\n  %s\n', S.savedPaths{:});
