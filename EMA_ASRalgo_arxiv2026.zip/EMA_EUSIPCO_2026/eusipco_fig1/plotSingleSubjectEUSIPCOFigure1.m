    function S = plotSingleSubjectEUSIPCOFigure1(subjectID, opts)
    %PLOTSINGLESUBJECTEUSIPCOFIGURE1  Reproduce EUSIPCO 2026 Fig. 1 for one subject.
    %
    %   Five panels are produced:
    %     - mean principal angle between the calibration subspace V_ref and
    %       the top-k eigenvectors of a 2-s sliding-window covariance
    %     - fraction of window-covariance energy retained by V_ref
    %     - heatmaps of Sigma_cal, Sigma_closed, Sigma_open
    %
    %   Defaults follow the paper: subject 10, raw signal, calibration on
    %   [7, 60] s, subspace rank k = 5, 2-s windows at 50% overlap, and the
    %   rASR block-geometric-median covariance estimator.
    
        if nargin < 1 || isempty(subjectID), subjectID = 10; end
        if nargin < 2, opts = struct(); end
        defaults = struct( ...
            'fs',             500, ...
            'calibSec',       [7 60], ...
            'windowSec',      2.0, ...
            'hopSec',         1.0, ...
            'subspaceRank',   5, ...
            'blockSize',      10, ...
            'climPercentile', 95, ...
            'dataPath',       'K:\ArtifactSubspaceReconstruction\datasets', ...
            'saveDir',        'I:\verification-script_CNG\figs');
        for f = fieldnames(defaults)'
            if ~isfield(opts, f{1}), opts.(f{1}) = defaults.(f{1}); end
        end
        if ~isfolder(opts.saveDir), mkdir(opts.saveDir); end
    
        fs = opts.fs;
        k  = opts.subspaceRank;
    
        % --- Load and segment by event latency ---------------------------
        [X, latency] = loadSubject(subjectID, opts.dataPath);
        calStart = round(opts.calibSec(1) * fs);
        calEnd   = round(opts.calibSec(2) * fs);
        Xcal     = X(:, calStart   : calEnd);
        Xclosed  = X(:, calEnd + 1 : latency - 1);
        Xopen    = X(:, latency    : end);
    
        % --- Robust state covariances and calibration subspace -----------
        Sigma_cal    = robustBlockCov(Xcal,    opts.blockSize);
        Sigma_closed = robustBlockCov(Xclosed, opts.blockSize);
        Sigma_open   = robustBlockCov(Xopen,   opts.blockSize);
    
        % eig of a symmetric matrix returns eigenvalues in ascending order,
        % so the dominant k eigenvectors sit at the right of V.
        [V, ~] = eig(Sigma_cal);
        V_ref  = V(:, end - k + 1 : end);
    
        % --- Sliding-window angle drift and energy capture ---------------
        closed = slidingTraces(Xclosed, fs, opts.windowSec, opts.hopSec, V_ref);
        open_  = slidingTraces(Xopen,   fs, opts.windowSec, opts.hopSec, V_ref);
    
        % --- Render and save ---------------------------------------------
        fig  = drawFigure(subjectID, closed, open_, ...
            Sigma_cal, Sigma_closed, Sigma_open, opts);
        base = fullfile(opts.saveDir, sprintf('eusipco_fig1_subject_%d', subjectID));
        print(fig, [base '.png'], '-dpng', '-r300');
        print(fig, [base '.pdf'], '-dpdf', '-bestfit');
    
        S = struct( ...
            'subjectID',    subjectID, ...
            'V_ref',        V_ref, ...
            'Sigma_cal',    Sigma_cal, ...
            'Sigma_closed', Sigma_closed, ...
            'Sigma_open',   Sigma_open, ...
            'closed',       closed, ...
            'open',         open_, ...
            'figHandle',    fig, ...
            'savedPaths',   {{[base '.png'], [base '.pdf']}});
    end
    
    % =====================================================================
    function [X, latency] = loadSubject(subjectID, dataPath)
    % First entry of EEG.event marks the eyes-closed -> eyes-open transition;
    % if no event is logged, fall back to the recording midpoint.
        d = load(fullfile(dataPath, sprintf('subject_%d.mat', subjectID)));
        X = double(d.EEG.data);
        if isfield(d.EEG, 'event') && ~isempty(d.EEG.event)
            latency = round(d.EEG.event(1).latency);
        else
            latency = round(size(X, 2) / 2);
        end
    end
    
    % =====================================================================
    function C = robustBlockCov(X, blocksize)
    % rASR estimator: geometric median of per-block sample covariance over
    % non-overlapping blocks of length `blocksize`.
        [Ch, T] = size(X);
        Xt = X';
        U = zeros(numel(1:blocksize:T), Ch*Ch);
        for k = 1:blocksize
            rng = min(T, k:blocksize:(T + k - 1));
            U = U + reshape(bsxfun(@times, ...
                reshape(Xt(rng, :), [], 1, Ch), ...
                reshape(Xt(rng, :), [], Ch, 1)), size(U));
        end
        C = real(reshape(block_geometric_median(U / blocksize), Ch, Ch));
    end
    
    % =====================================================================
    function seg = slidingTraces(X, fs, windowSec, hopSec, V_ref)
    % For each window w:
    %   theta(w) = mean principal angle (deg) between V_ref and the top-k
    %              eigenvectors of the window covariance C_w
    %   eta(w)   = trace(V_ref' C_w V_ref) / trace(C_w)        in [0, 1]
        [~, T] = size(X);
        N      = round(windowSec * fs);
        hop    = round(hopSec    * fs);
        starts = 1 : hop : (T - N + 1);
        nW     = numel(starts);
        k      = size(V_ref, 2);
    
        angle  = zeros(1, nW);
        energy = zeros(1, nW);
        for w = 1:nW
            Xw = X(:, starts(w) : starts(w) + N - 1);
            Cw = cov(Xw');
            energy(w) = trace(V_ref' * Cw * V_ref) / trace(Cw);
    
            [Vw, ~]  = eig(Cw);
            sv       = svd(V_ref' * Vw(:, end - k + 1 : end));
            angle(w) = mean(rad2deg(acos(min(max(sv, -1), 1))));
        end
    
        seg = struct( ...
            'time',          (starts + N/2 - 1) / fs, ...
            'angle',         angle, ...
            'energyCapture', energy);
    end
    
    % =====================================================================
    function f = drawFigure(subjectID, closed, open_, ...
                            Sigma_cal, Sigma_closed, Sigma_open, opts)
        f = figure('Color', 'w', 'Position', [80 60 1500 760]);
        cClosed = [0.20 0.45 0.85];
        cOpen   = [0.85 0.35 0.10];
    
        nC   = numel(closed.angle);
        nO   = numel(open_.angle);
        xC   = 1:nC;
        xO   = nC + (1:nO);
        xSep = nC + 0.5;
    
        % Top-left: subspace angle drift
        subplot('Position', [0.06 0.56 0.55 0.36]); hold on;
        plot(xC, closed.angle, '-', 'Color', cClosed, 'LineWidth', 1.6);
        plot(xO, open_.angle,  '-', 'Color', cOpen,   'LineWidth', 1.6);
        xline(xSep, 'k:'); grid on; box on; xlim([0 nC + nO + 1]);
        xlabel('Window'); ylabel('Degrees');
        title('Mean Subspace Angle Drift');
        legend({'Closed', 'Open'}, 'Location', 'southeast');
    
        % Bottom-left: energy capture
        subplot('Position', [0.06 0.08 0.55 0.36]); hold on;
        plot(xC, closed.energyCapture, '-', 'Color', cClosed, 'LineWidth', 1.6);
        plot(xO, open_.energyCapture,  '-', 'Color', cOpen,   'LineWidth', 1.6);
        xline(xSep, 'k:'); grid on; box on; xlim([0 nC + nO + 1]);
        xlabel('Window'); ylabel('Energy Captured');
        title('Calibration Subspace Energy Capture');
        legend({'Eyes Closed', 'Eyes Open'}, 'Location', 'southwest');
    
        % Right column: three covariance heatmaps with a shared symmetric clim
        cmax = prctile(abs([Sigma_cal(:); Sigma_closed(:); Sigma_open(:)]), ...
                       opts.climPercentile);
        drawCov([0.66 0.62 0.14 0.31], Sigma_cal,    cmax, 'Calibration');
        drawCov([0.66 0.16 0.14 0.31], Sigma_closed, cmax, 'Eyes-Closed');
        drawCov([0.83 0.39 0.14 0.31], Sigma_open,   cmax, 'Eyes-Open');
    
        annotation('textbox', [0.05 0.96 0.9 0.035], ...
            'String', sprintf( ...
                'Subject %d  -  cal=[%g,%g]s,  k=%d,  win=%gs,  hop=%gs', ...
                subjectID, opts.calibSec(1), opts.calibSec(2), ...
                opts.subspaceRank, opts.windowSec, opts.hopSec), ...
            'EdgeColor', 'none', 'FontSize', 11, 'FontWeight', 'bold');
    end
    
    % =====================================================================
    function drawCov(pos, M, cmax, label)
        subplot('Position', pos);
        imagesc(M); axis square; colormap(jet); caxis([-cmax cmax]); colorbar;
        n = size(M, 1);
        set(gca, 'XTick', 1:max(2, round(n/8)):n, ...
                 'YTick', 1:max(2, round(n/8)):n, 'FontSize', 7);
        title(['Covariance Structure: ' label], 'FontSize', 9);
    end
