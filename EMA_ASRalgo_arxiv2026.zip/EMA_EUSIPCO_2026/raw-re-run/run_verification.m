% run_verification.m
%
% ONE-SUBJECT SMOKE TEST  --  single entry point for the EMA-ASR handoff.
%
% Regenerates BOTH EUSIPCO 2026 figures completely fresh, for ONE subject on a
% short cut-off grid, to confirm the package runs end to end on a clean machine
% (e.g. straight after unzipping the download). Nothing in the shipped package
% is touched -- every output is written under  raw-re-run/out/ .
%
% Pipeline exercised:
%   [1] Figure 1  -- calibration-subspace tracking
%                    (plotSingleSubjectEUSIPCOFigure1)
%   [2] Figure 2  -- cut-off sweep for baseline / adaptive (/ HMO) ASR, then the
%                    combined cohort panel
%                    (compute_asr_cutoff_sweep  ->  plotEUSIPCOFigure2)
%
% --------------------------------------------------------------------- TO RUN
%   1. Drop the un-shipped ASR functions into  raw-re-run/deps/  (run this
%      script once and it prints exactly which are missing, then stops):
%         helperASR_cleaning_preporcessEEG.m
%         asr_calibrate.m            asr_process.m            (baseline / static)
%         asr_calibrate_Version1.m   asr_process_version1.m   (adaptive / EMA)
%         hmo_asr_calibrate.m        hmo_asr_process.m        (HMO, optional)
%      ...plus any EEGLAB clean_rawdata helpers they call (e.g. fit_eeg_distribution).
%   2. Press Run  (or type  run_verification  at the prompt).
%
% The raw recording is read from the bundled  codebase/dataset/  by default, so
% no data needs to be attached. Edit the Config block to change the subject,
% the cut-off grid, or the data location.

clear; clc; close all;

% =============================== Config ==================================
SUBJECT_ID  = 1;                  % which subject_<n>.mat to smoke-test
CUTOFF_GRID = [5 20 100];         % short grid -> fast (the paper grid is ~16 pts)
USE_GPU     = false;              % false keeps the smoke test portable

% ===================== Locate package + wire up path =====================
thisDir = fileparts(mfilename('fullpath'));      % .../EMA-ASR-handoff/raw-re-run
pkgRoot = fileparts(thisDir);                     % .../EMA-ASR-handoff

fig1Dir = fullfile(pkgRoot, 'eusipco_fig1');
fig2Dir = fullfile(pkgRoot, 'eusipco_fig2');
genDir  = fullfile(fig2Dir, 'generate');
depsDir = fullfile(thisDir, 'deps');                       % user-supplied ASR fns
rawDir  = fullfile(pkgRoot, 'codebase', 'dataset');        % bundled raw recordings
outData = fullfile(thisDir, 'out', 'data');                % fresh sweeps land here
outFigs = fullfile(thisDir, 'out', 'figs');                % fresh figures land here

for d = {depsDir, outData, outFigs}
    if ~isfolder(d{1}), mkdir(d{1}); end
end
addpath(fig1Dir, fig2Dir, genDir, depsDir);

% ===================== Pre-flight dependency check =======================
reqFun = {'helperASR_cleaning_preporcessEEG', ...
          'asr_calibrate',          'asr_process', ...
          'asr_calibrate_Version1', 'asr_process_version1'};
missing  = reqFun(cellfun(@(f) exist(f, 'file') == 0, reqFun));
haveHMO  = exist('hmo_asr_calibrate', 'file') && exist('hmo_asr_process', 'file');
subjFile = fullfile(rawDir, sprintf('subject_%d.mat', SUBJECT_ID));

if ~isempty(missing) || ~isfile(subjFile)
    fprintf(2, '\n==== CANNOT RUN -- supply the following, then re-run ====\n');
    if ~isfile(subjFile)
        fprintf(2, '  raw recording : %s  (not found)\n', subjFile);
    end
    for i = 1:numel(missing)
        fprintf(2, '  function      : %s.m  ->  drop in %s\n', missing{i}, depsDir);
    end
    if ~haveHMO
        fprintf(2, '  optional      : hmo_asr_calibrate.m / hmo_asr_process.m  (else HMO column is a placeholder)\n');
    end
    fprintf(2, '=========================================================\n');
    return;
end

fprintf('Smoke test  |  subject %d  |  cut-offs [%s]  |  GPU %d\n', ...
        SUBJECT_ID, strtrim(num2str(CUTOFF_GRID)), USE_GPU);

% =============================== Figure 1 ================================
fprintf('\n[1/2] Figure 1 -- subspace tracking ...\n');
S1 = plotSingleSubjectEUSIPCOFigure1(SUBJECT_ID, struct( ...
        'dataPath', rawDir, ...
        'saveDir',  outFigs));
fprintf('      saved: %s\n', S1.savedPaths{1});

% =============================== Figure 2 ================================
fprintf('\n[2/2] Figure 2 -- cut-off sweep (fresh from raw) ...\n');
sweepOpts = struct( ...
    'subjectIDs', SUBJECT_ID, ...
    'subjectDir', rawDir, ...
    'cutoffs',    CUTOFF_GRID, ...
    'useGPU',     USE_GPU, ...
    'saveDir',    outData);

runMethods = {'baseline', 'adaptive'};
if haveHMO, runMethods{end+1} = 'hmo'; end
for m = runMethods
    compute_asr_cutoff_sweep(m{1}, sweepOpts);
end

% A single-subject sweep pads the per-subject cell arrays with empties (the cell
% index equals the subject ID). Drop the empty cells so plotEUSIPCOFigure2 can
% stack them; for SUBJECT_ID = 1 this is a no-op.
swept = dir(fullfile(outData, '*.mat'));
cols  = {'dataModified_data', 'varianceReduced_data', ...
         'dataModified_calib', 'varianceReduced_calib'};
for i = 1:numel(swept)
    fp = fullfile(outData, swept(i).name);
    d  = load(fp);
    if ~isfield(d, 'dataModified_data'), continue; end
    keep = ~cellfun(@isempty, d.dataModified_data);
    for c = 1:numel(cols), d.(cols{c}) = d.(cols{c})(keep); end
    save(fp, '-struct', 'd');
end

S2 = plotEUSIPCOFigure2(struct( ...
        'dataPath', outData, ...
        'saveDir',  outFigs, ...
        'hmoFile',  'ASR_HMO_cutOff_exp.mat'));   % absent -> HMO placeholder column
fprintf('      saved: %s\n', S2.savedPaths{1});

% ================================= Done ==================================
fprintf('\n==================  SMOKE TEST PASSED  ==================\n');
fprintf('Fresh figures and sweep data written under:\n');
fprintf('  %s\n  %s\n', outFigs, outData);
