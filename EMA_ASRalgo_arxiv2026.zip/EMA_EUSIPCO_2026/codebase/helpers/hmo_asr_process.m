function [outdata, outstate] = hmo_asr_process(data, srate, state, windowlen, lookahead, stepsize, maxdims, maxmem, usegpu)
% HMO-ASR streaming (paper-faithful math) + causal look-ahead.
% Uses a delay of P = round(lookahead*fs) so each window can use future samples.

    if nargin < 4 || isempty(windowlen), windowlen = state.window_len; end
    if nargin < 5 || isempty(lookahead), lookahead = state.lookahead;  end
    if nargin < 6 || isempty(stepsize),  stepsize  = windowlen;        end  % default: non-overlap
    if nargin < 7 || isempty(maxdims),   maxdims   = 1;             end
    if nargin < 8 || isempty(maxmem),    maxmem    = 512;              end %#ok<NASGU>
    if nargin < 9 || isempty(usegpu),    usegpu    = false;            end %#ok<NASGU>

    if maxdims < 1, maxdims = round(size(data,1)*maxdims); end
    if isempty(data), outdata = data; outstate = state; return; end

    [C,S] = size(data);

        % Fallback init if calibrate state lacks channel-RMS stats
    if ~isfield(state,'ch_mu') || ~isfield(state,'ch_var') || ~isfield(state,'n_rms')
        state.ch_mu = zeros(C,1);
        state.ch_var = ones(C,1);
        state.n_rms = 0;
    end
    if ~isfield(state,'iir'), state.iir = []; end


    Nw  = max(1, round(windowlen * srate));
    hop = max(1, round(stepsize * srate));
    P   = max(0, round(lookahead * srate));     % causal delay

    % ----- prepend lookahead buffer (raw) -----
    if isempty(state.carry)
        if S >= 2
            first = data(:,1); second = data(:,2);
            trend = 2*first - second;  % simple linear extrap seed
        else
            trend = data(:,1);
        end
        state.carry = repmat(trend, 1, P);
    end
    data_ext = [state.carry, data];             % [C x (P+S)]
    data_ext(~isfinite(data_ext)) = 0;

    % ----- filtered copy for gating/stats -----
    [Xf, state.iir] = filter(state.B, state.A, double(data_ext), state.iir, 2);
    Xf = Xf.';                                   % [P+S x C]

    % ----- window starts (ensure full windows) -----
    totalS = size(Xf,1);
    win_starts = (P+1):hop:(totalS - Nw + 1);    % start after the prepended buffer

    % ----- output buffer (will overwrite per block) -----
    cleaned = data_ext;

    for w = 1:numel(win_starts)
        a = win_starts(w); b = a + Nw - 1;

        W_raw  = data_ext(:, a:b).';             % [Nw x C], raw for synthesis
        W_filt = Xf( a:b, : );                   % [Nw x C], filtered for stats

        % ---- Level-1 & Level-2 (as calibration) ----
        [Wpp, ~] = local_pca_eig_zprune(W_filt, 1.5);

        ch_rms = sqrt(mean(Wpp.^2,1)).';
        [state.ch_mu, state.ch_var, state.n_rms] = local_update_mean_var(state.ch_mu, state.ch_var, state.n_rms, ch_rms);
        z_ch = (ch_rms - state.ch_mu) ./ max(1e-12, sqrt(state.ch_var));
        is_clean = all(z_ch >= state.z_clean_range(1) & z_ch <= state.z_clean_range(2));

        % ---- Update clean-model on CLEAN windows only (Eq. 4–6) ----
        if is_clean
            n_star = size(Wpp,1);
            if n_star >= 2
                m_star = mean(Wpp,1).';
                Xc     = Wpp - m_star.';
                C_star = (Xc.'*Xc) / (n_star-1);

                n_new = state.n_tot + n_star;
                if state.n_tot == 0
                    m_new = m_star; C_new = C_star;
                else
                    delta = (state.m_ch - m_star);
                    m_new = state.m_ch + (m_star - state.m_ch)*(n_star/n_new);
                    C_new = ( ((state.n_tot-1)*state.C_ch) + ((n_star-1)*C_star) ...
                            + (state.n_tot*n_star/n_new)*(delta*delta.') ) / (n_new-1);
                end
                state.n_tot = n_new; state.m_ch = m_new; state.C_ch = C_new;

                % Early-eigen reuse
                need_eig = isempty(state.E);
                if ~need_eig
                    Rtest = state.E.' * state.C_ch * state.E;
                    od = sum(abs(Rtest(:))) - sum(abs(diag(Rtest)));
                    dg = sum(abs(diag(Rtest))) + 1e-12;
                    need_eig = (od/dg) >= state.eigen_threshold;
                end
                if need_eig
                    E_old = state.E; if isempty(E_old), E_old = eye(C); end
                    [E_new, Dc] = eig((state.C_ch+state.C_ch.')/2);
                    if ~isempty(state.mu_pc)
                        [state.mu_pc, state.var_pc] = project_stats_onto_new_basis(state.mu_pc, state.var_pc, E_old, E_new);
                    end
                    state.E = E_new;
                    lam_c   = max(0, real(diag(Dc)));
                else
                    lam_c   = max(0, real(diag(state.E.'*state.C_ch*state.E)));
                end
                state.sqrtC = state.E * diag(sqrt(lam_c)) * state.E.';

                % Per-PC RMS & thresholds (clean only)
                Y = (state.E.' * Wpp.').'; pc_rms = sqrt(mean(Y.^2,1)).';
                if isempty(state.mu_pc), state.mu_pc = pc_rms; state.var_pc = ones(C,1)*1e-6; end
                [state.mu_pc, state.var_pc, ~] = local_update_mean_var(state.mu_pc, state.var_pc, w, pc_rms, true);
                state.Tpc = state.mu_pc + state.cutoff*sqrt(max(state.var_pc,0));
            end
        end

        % ---- Reconstruction (Eq. 10–11) ----
        [Ek, Dk] = eig( (W_filt.'*W_filt)/max(1,Nw) ); lam = real(diag(Dk));

        if isempty(state.E)
            Tproj = state.Tpc.^2;
        else
            Q = state.E.' * Ek;                 % rotate thresholds into window-PC domain
            Tproj = (Q.^2).' * (state.Tpc.^2);  % [C x 1]
        end

        reject = lam > Tproj;
        if maxdims < C
            [~,ord] = sort(lam,'ascend');
            keep_force = ord(1:(C-maxdims));
            reject(keep_force) = false;
        end

        M  = state.sqrtC;
        G  = Ek.' * M;           % [C x C]
        Gt = G;  Gt(reject,:) = 0;
        Rproj = M * pinv(Gt) * Ek.';   % projector

        Wclean = (Rproj * W_raw.').';
        cleaned(:, a:b) = Wclean.';    % non-overlapped write-back
    end

    % ----- prepare carry and finalize alignment -----
    % carry = last P raw samples to prepend next call
    state.carry = data_ext(:, end-P+1:end);
    % output aligned to current input by dropping trailing P
    outdata  = cleaned(:, 1:end-P);
    outstate = state;
end

% ---------------------- helpers ----------------------
function [Wclean, kept] = local_pca_eig_zprune(W, zcut)
    COV = (W.'*W) / max(1,size(W,1));
    [E,D] = eig((COV+COV.')/2);
    lam   = real(diag(D));
    z  = (lam - mean(lam)) / (std(lam)+1e-12);
    kept = z <= zcut;
    E2 = E(:, kept);
    if isempty(E2)
        [~,i] = min(lam);
        E2 = E(:,i);
        kept = false(size(kept)); kept(i)=true;
    end
    Wclean = (E2 * (E2.' * W.')).';
end

function [mu, varv, n] = local_update_mean_var(mu, varv, n, x, robust_init)
    if nargin < 5, robust_init = false; end
    x = x(:);
    if n == 0
        mu = x; varv = ones(size(x))*(robust_init*1e-6); n = 1; return;
    end
    n_new = n+1; delta = x - mu; mu_new = mu + delta./n_new;
    M2_old = varv.*max(1,(n-1)); M2_new = M2_old + delta.*(x - mu_new);
    var_new= M2_new ./ max(1,(n_new-1));
    mu=mu_new; varv=max(var_new,0); n=n_new;
end

function [mu_new, var_new] = project_stats_onto_new_basis(mu_old, var_old, E_old, E_new)
    Q = E_old.' * E_new;
    s2_old = mu_old.^2 + var_old;
    s2_new = (Q.^2).' * s2_old;
    var_new = (Q.^2).' * var_old;
    mu_new  = sqrt(max(s2_new - var_new, 0));
end
