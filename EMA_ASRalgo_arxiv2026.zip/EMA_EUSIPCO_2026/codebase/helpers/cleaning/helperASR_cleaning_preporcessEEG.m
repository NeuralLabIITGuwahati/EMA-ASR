function cleanedSignal = helperASR_cleaning_preporcessEEG(signal,fs)
% Zero-center each channel
mean_value = mean(signal, 2);
signal = signal - mean_value;
% Z-score normalization across time (per channel)
signal = normalize(signal, 2, 'zscore');
% Notch Filter Application
cleanedSignal = helperASR_cleaning_applyNotchFilterEEG(signal,fs); 

end