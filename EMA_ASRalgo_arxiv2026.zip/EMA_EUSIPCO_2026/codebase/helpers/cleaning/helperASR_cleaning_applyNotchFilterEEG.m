function cleanedSignal = applyNotchFilterEEG(signal,fs)
%% Notch Filtering at 50 Hz
notch_freq = 50;                % Line noise frequency
wo = notch_freq / (fs/2);       % Normalized frequency
bw = wo / 35;                   % Bandwidth
[b, a] = iirnotch(wo, bw);

% Apply zero-phase notch filter
cleanedSignal = filtfilt(b, a, signal')'; % Ensure signals are column Vectors!
end