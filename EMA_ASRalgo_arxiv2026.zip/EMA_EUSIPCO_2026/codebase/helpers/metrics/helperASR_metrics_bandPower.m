function metrics = helperASR_metrics_bandPower(eeg, fs, bands)
    [nCh, ~] = size(eeg);
    metrics.total = zeros(nCh, 1);
    metrics.bandPower = struct();
    metrics.relativePower = struct();

    fRes = 0.5; % Frequency resolution for PSD
    for ch = 1:nCh
        [Pxx, f] = pwelch(eeg(ch, :), [], [], 0:fRes:fs/2, fs);  % PSD

        % Total power
        totalPower = trapz(f, Pxx);
        metrics.total(ch) = totalPower;

        % Band powers
        bandNames = fieldnames(bands);
        for i = 1:numel(bandNames)
            band = bandNames{i};
            range = bands.(band);
            idx = f >= range(1) & f < range(2);
            bandPow = trapz(f(idx), Pxx(idx));
            metrics.bandPower.(band)(ch, 1) = bandPow;
            metrics.relativePower.(band)(ch, 1) = bandPow / totalPower;
        end
    end

    % Optionally, average across channels (uncomment if needed)
    % metrics.total = mean(metrics.total);
    % fields = fieldnames(metrics.bandPower);
    % for i = 1:numel(fields)
    %     band = fields{i};
    %     metrics.bandPower.(band) = mean(metrics.bandPower.(band));
    %     metrics.relativePower.(band) = mean(metrics.relativePower.(band));
    % end
end