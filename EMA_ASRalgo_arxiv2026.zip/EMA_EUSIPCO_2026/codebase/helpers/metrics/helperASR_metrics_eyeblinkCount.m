function [nblinks_o,nblinks_c,blink_indicesOriginal,blink_indicesASR,thres1] = helperASR_metrics_eyeblinkCount(XClean,XOriginal,fs)
    
    % Function to perform ASR on single channel signal.
    
    % Inputs:    
    %   X: single channel signal of size (1,n) where n is length of signal,
    %   before cleaning
    %   XClean: single channel signal of size (1,n) where n is length of
    %   signal, after cleaning
    %   fs: sampling rate in Hertz.
    
    % Output:
    %   nblinks_o: No. of eye blinks in signal before ASR
    %   nblinks_c: No. of eye blinks in signal after ASR
        
    signalOriginal = XOriginal;
    signalASR = XClean;

    % signalOriginal = normalize(X,2);
    % signalASR = normalize(XClean,2);
    
    % Setting threshold value for minimum peak height
    thres1 = 6*mean(abs(signalOriginal),2);
    
    % Apply findpeaks row-wise on X (original) and Xclean (ASR-cleaned)
    [~, blink_indicesOriginal] = arrayfun(@(i) ...
        findpeaks(XOriginal(i, :), 'MinPeakHeight', thres1(i), 'MinPeakDistance', 0.2*fs), ...
        (1:size(XOriginal, 1))', 'UniformOutput', false);

    [~, blink_indicesASR] = arrayfun(@(i) ...
        findpeaks(XClean(i, :), 'MinPeakHeight', thres1(i), 'MinPeakDistance', 0.5*fs), ...
        (1:size(XClean, 1))', 'UniformOutput', false);

    % Number of blinks per channel (row)
    nblinks_o = cellfun(@numel, blink_indicesOriginal);  % original
    nblinks_c = cellfun(@numel, blink_indicesASR); 

    disp('Eye-blinks counted.')
end