function summary = helperASR_metrics_spectralSummary(originalEEG, cleanedEEG, fs)
% summarizeEEGBandPower - Wrapper to compare total and relative power in EEG bands
%
% Inputs:
%   originalEEG - Raw EEG matrix (channels x time)
%   cleanedEEG  - Cleaned EEG matrix (channels x time)
%   fs          - Sampling frequency in Hz
%
% Output:
%   summary - Struct with average total and relative power per band before and after cleaning

    % Run core spectral power comparison
    powerMetrics = helperASR_metrics_spectralAnalysis(originalEEG, cleanedEEG, fs);

    % Band list
    bands = {'delta', 'theta', 'alpha', 'beta', 'gamma'};

    % Initialize summary struct
    for i = 1:numel(bands)
        band = bands{i};
        % Average band power and relative power across channels
        summary.(band).totalPowerBefore = mean(powerMetrics.before.bandPower.(band));
        summary.(band).totalPowerAfter  = mean(powerMetrics.after.bandPower.(band));
        summary.(band).relativePowerBefore = mean(powerMetrics.before.relativePower.(band));
        summary.(band).relativePowerAfter  = mean(powerMetrics.after.relativePower.(band));
    end

    % Also include total power
    summary.totalPowerBefore = mean(powerMetrics.before.total);
    summary.totalPowerAfter  = mean(powerMetrics.after.total);
end