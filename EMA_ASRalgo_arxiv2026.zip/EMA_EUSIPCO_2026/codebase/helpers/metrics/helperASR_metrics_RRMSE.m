function [RRMSE, avgRRMSE] = helperASR_metrics_RRMSE(originalEEG, cleanedEEG)
% computeRRMSE - Computes Relative Root Mean Square Error (RRMSE) between original and cleaned EEG signals
%
% Syntax: [RRMSE, avgRRMSE] = computeRRMSE(originalEEG, cleanedEEG)
%
% Inputs:
%   originalEEG - Matrix of original EEG data (channels x time)
%   cleanedEEG  - Matrix of cleaned EEG data (same size as originalEEG)
%
% Outputs:
%   RRMSE       - RRMSE per channel (column vector)
%   avgRRMSE    - Mean RRMSE across all channels

    % Validate input size
    if ~isequal(size(originalEEG), size(cleanedEEG))
        error('Input dimensions must match: originalEEG and cleanedEEG must be the same size.');
    end

    % Compute RMSE per channel
    rmse = sqrt(mean((originalEEG - cleanedEEG).^2, 2));
    
    % Compute RMS of original EEG per channel
    rmsOriginal = sqrt(mean(originalEEG.^2, 2));
    
    % Compute RRMSE per channel
    RRMSE = rmse ./ rmsOriginal;
    
    % Compute average RRMSE across all channels
    avgRRMSE = mean(RRMSE);
end