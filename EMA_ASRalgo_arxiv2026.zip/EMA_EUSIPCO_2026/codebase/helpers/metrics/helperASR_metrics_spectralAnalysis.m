function [powerMetrics] = helperASR_metrics_spectralAnalysis(originalEEG, cleanedEEG, fs)
% compareSpectralPower - Compares spectral power before and after cleaning EEG
%
% Inputs:
%   originalEEG - EEG signal before cleaning (channels x time)
%   cleanedEEG  - EEG signal after cleaning (channels x time)
%   fs          - Sampling frequency in Hz
%
% Output:
%   powerMetrics - Struct with total and band power (absolute and relative) before and after

    % Define EEG frequency bands
    bands = struct(...
        'delta', [1 4], ...
        'theta', [4 8], ...
        'alpha', [8 13], ...
        'beta',  [13 30], ...
        'gamma', [30 100]);

    % Compute power for both signals
    powerMetrics.before = helperASR_metrics_bandPower(originalEEG, fs, bands);
    powerMetrics.after  = helperASR_metrics_bandPower(cleanedEEG, fs, bands);
end