function state = hmo_asr_calibrate(X, srate, cutoff, window_len, window_overlap, eigen_threshold, z_clean_range, maxmem, B, A)
% HMO-ASR calibration (paper-faithful) + stores default lookahead for streaming.

    if nargin < 3 || isempty(cutoff),         cutoff = 10;          end
    if nargin < 4 || isempty(window_len),     window_len = 0.5;     end
    if nargin < 5 || isempty(window_overlap), window_overlap = 0.0; end   % stats hop (kept 0 here)
    if nargin < 6 || isempty(eigen_threshold),eigen_threshold = 0.002; end
    if nargin < 7 || isempty(z_clean_range),  z_clean_range = [-3 5];    end
    if nargin < 8 || isempty(maxmem),         maxmem = 512;             end %#ok<NASGU>

    X(~isfinite(X)) = 0;
    [C,S] = size(X);

    % ----- spectral weighting (ASR-style) -----
    if nargin < 10 || isempty(A) || isempty(B)
        [B,A] = local_default_weighting_filter(srate);
    end
    [Xf,iirstate] = filter(B,A,double(X),[],2);
    Xf = Xf.';                                    % [S x C]

    % ----- windows (for stats only) -----
    Nw  = max(1, round(window_len*srate));
    hop = max(1, round(Nw*(1-window_overlap)));
    win_starts = 1:hop:max(1,S-Nw+1);

    % ----- channel-RMS gate stats -----
    n_rms  = 0;
    ch_mu  = zeros(C,1);
    ch_var = ones(C,1);
% ----- covariance deviation (z-score) gate stats -----
n_dev   = 0;
mu_dev  = 0;
var_dev = 1;   % nonzero to avoid divide-by-zero

    % ----- parallel mean/std/cov over CLEAN windows (Eq. 4–6) -----
    n_tot = 0; m_ch = zeros(C,1); C_ch = zeros(C);
    E_prev = []; sqrtC = []; mu_pc = []; var_pc = [];

    for ws = 1:numel(win_starts)
        idx = win_starts(ws):(win_starts(ws)+Nw-1);
        if idx(end) > S, break; end

        W = Xf(idx,:);                               % [Nw x C]
        % [Wpp, ~] = local_pca_eig_zprune(W, 1.5);     % Level-1 prune
        Wpp = W;   % calibration data must remain unaltered




        % ch_rms = sqrt(mean(Wpp.^2,1)).';
        % [ch_mu, ch_var, n_rms] = local_update_mean_var(ch_mu, ch_var, n_rms, ch_rms);
        % z_ch = (ch_rms - ch_mu) ./ max(1e-12, sqrt(ch_var));
        % if ~all(z_ch >= z_clean_range(1) & z_ch <= z_clean_range(2)), continue; end

        % Parallel mean/cov update (clean only)
        n_star = size(Wpp,1); if n_star < 2, continue; end
        m_star = mean(Wpp,1).'; Xc = Wpp - m_star.'; C_star = (Xc.'*Xc)/(n_star-1);

        n_new = n_tot + n_star;
        if n_tot == 0
            m_new = m_star; C_new = C_star;
        else
            delta = (m_ch - m_star);
            m_new = m_ch + (m_star - m_ch)*(n_star/n_new);
            C_new = ( ((n_tot-1)*C_ch) + ((n_star-1)*C_star) + (n_tot*n_star/n_new)*(delta*delta.') ) / (n_new-1);
        end
        n_tot = n_new; m_ch = m_new; C_ch = C_new;

        % Early-eigen reuse & sqrtC
        if isempty(E_prev)
            [E_prev,Dc] = eig((C_ch+C_ch.')/2);
            lam = max(0, real(diag(Dc)));
        else
            Rtest = E_prev.' * C_ch * E_prev;
            offd  = sum(abs(Rtest(:))) - sum(abs(diag(Rtest)));
            diagv = sum(abs(diag(Rtest))) + 1e-12;
            if (offd/diagv) >= eigen_threshold
                E_old = E_prev;
                [E_prev,Dc] = eig((C_ch+C_ch.')/2);
                if ~isempty(mu_pc)
                    [mu_pc, var_pc] = project_stats_onto_new_basis(mu_pc, var_pc, E_old, E_prev);
                end
                lam = max(0, real(diag(Dc)));
            else
                lam = max(0, real(diag(Rtest)));
            end
        end
        sqrtC = E_prev * diag(sqrt(lam)) * E_prev.';

                        % Level-2 gate on channel RMS
Cw = cov(Wpp,1);
Delta = sqrtC \ Cw / sqrtC;   % whitened covariance
dev = norm(Delta - eye(C), 'fro');
z_clean_range = [-3 5];


% update dev stats only on accepted windows
if n_dev == 0
    mu_dev = dev;
    var_dev = 1e-6;
    n_dev = 1;
    z_dev = 0;
else
    z_dev = (dev - mu_dev) / sqrt(var_dev + 1e-12);
end

% z-score gate (clean covariance consistency)
if z_dev < z_clean_range(1) || z_dev > z_clean_range(2)
    continue;
end

% update dev mean/variance AFTER acceptance
[mu_dev, var_dev, n_dev] = local_update_mean_var(mu_dev, var_dev, n_dev, dev);

Xw = Wpp.';   % [C × N]
Einv = inv(sqrtC);   % or use Cholesky
Z = Einv * Xw;
energy_clean = mean(sum(Z.^2,1));
mu_E  = mean(energy_clean);
sig_E = std(energy_clean);
T = mu_E + cutoff * sig_E;



        % Per-PC RMS stats (clean only)
        Y = (E_prev.' * Wpp.').'; pc_rms = sqrt(mean(Y.^2,1)).';
        if isempty(mu_pc), mu_pc = pc_rms; var_pc = ones(C,1)*1e-6; end
        [mu_pc, var_pc, ~] = local_update_mean_var(mu_pc, var_pc, ws, pc_rms, true);
    end

    % Fallbacks
    if isempty(E_prev)
        E_prev = eye(C);
        lam    = max(0, real(diag((Xf.'*Xf)/max(1,S))));
        sqrtC  = E_prev * diag(sqrt(lam)) * E_prev.';
    end
    if isempty(mu_pc)
        lam_now = max(0, real(diag(E_prev.'*C_ch*E_prev)));
        mu_pc   = sqrt(lam_now); var_pc = ones(C,1)*1e-6;
    end

    % thresholds (amplitude domain)
    Tpc = mu_pc + cutoff*sqrt(max(var_pc,0));

    % ----- pack state -----
    state = struct();
    state.srate           = srate;
    state.B               = B;
    state.A               = A;
    state.iir             = iirstate;

    state.window_len      = window_len;
    state.window_overlap  = window_overlap;
    state.cutoff          = cutoff;
    state.eigen_threshold = eigen_threshold;
    state.z_clean_range   = z_clean_range;

    % clean-model
    state.n_tot = n_tot; state.m_ch = m_ch; state.C_ch = C_ch;
    state.E = E_prev; state.sqrtC = sqrtC;
    state.mu_pc = mu_pc; state.var_pc = var_pc; state.Tpc = Tpc;

        % channel-RMS gate stats (needed by process)
    state.n_rms = n_rms;
    state.ch_mu = ch_mu;
    state.ch_var = ch_var;

    
    % default lookahead for streaming (paper used none; we store 0.5*win)
    state.lookahead = window_len/2;   % seconds (used only by process if caller passes [])
    state.carry     = [];             % for lookahead buffering
end

% ---------- helpers ----------
function [B,A] = local_default_weighting_filter(srate)
    freqvals = [[0 2 3 13 16 40 min(80, srate/2-1)]*2/srate 1];
    amps     = [3 0.75 0.33 0.33 1 1 3 3];
    if srate < 80, freqvals(end-2)=[]; amps(end)=[]; end
    try
        [B,A] = yulewalk(8, freqvals, amps);
    catch
        [B,A] = butter(4, 2*[0.5 min(45, srate/2-2)]/srate, 'bandpass');
    end
end

function [Wclean, kept] = local_pca_eig_zprune(W, zcut)
    COV = (W.'*W)/max(1,size(W,1));
    [E,D] = eig((COV+COV.')/2);
    lam = real(diag(D));
    z   = (lam - mean(lam)) / (std(lam)+1e-12);
    kept = z <= zcut;
    E2 = E(:, kept);
    if isempty(E2)
        [~,i] = min(lam); E2 = E(:,i); kept = false(size(kept)); kept(i)=true;
    end
    Wclean = (E2 * (E2.' * W.')).';
end

function [mu, varv, n] = local_update_mean_var(mu, varv, n, x, robust_init)
    if nargin < 5, robust_init = false; end
    x = x(:);
    if n == 0
        mu = x; varv = ones(size(x))*(robust_init*1e-6); n = 1; return;
    end
    n_new = n+1; delta = x - mu; mu_new = mu + delta./n_new;
    M2_old = varv.*max(1,(n-1)); M2_new = M2_old + delta.*(x - mu_new);
    var_new= M2_new ./ max(1,(n_new-1));
    mu=mu_new; varv=max(var_new,0); n=n_new;
end

function [mu_new, var_new] = project_stats_onto_new_basis(mu_old, var_old, E_old, E_new)
    Q = E_old.' * E_new; s2_old = mu_old.^2 + var_old;
    s2_new = (Q.^2).' * s2_old;
    var_new = (Q.^2).' * var_old;
    mu_new  = sqrt(max(s2_new - var_new, 0));
end
